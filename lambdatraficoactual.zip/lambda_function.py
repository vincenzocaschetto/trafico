import json
import difflib
import datetime
import requests

import pymongo
from pprint import pprint
client = pymongo.MongoClient("mongodb+srv://tfm:tfm123@cluster0-9biaw.azure.mongodb.net/test?retryWrites=true&w=majority")
db = client.TFM
import datetime
import random
trafico=db.trafico
camaras=db.camaras


def lambda_handler(event, context):
    # TODO implement
    calle=event['calle']
    cursor = trafico.find({"calle": calle}).sort('fecha',pymongo.DESCENDING).limit(10)
    promedio=0
    cantidad=0
    valorestrafico=[]
    etiquetastrafico=['Bajo', 'Medio','Alto']
    for dato in cursor:
        #pprint(dato)
        if(len(valorestrafico)==0):
            valorestrafico=dato['trafico']
        cantidad=cantidad+1
        promedio=promedio+dato['traficoactual']
    promedio=promedio/cantidad

    for i in range(len(valorestrafico)):
        if(valorestrafico[i]>promedio):
            etiqueta=etiquetastrafico[i]
            break
    valorestrafico
    etiqueta
    
    return {'traficoactual': etiqueta}

def insertarmedicion():
    calle=request.args.get('calle')
    traficoactual=request.args.get('traficoactual')
    encabezados=[]
    cuerpo={}
    horaactual=datetime.datetime.now().hour
    diaactual=datetime.datetime.now().weekday()
    dias=['L','M','X','J','V','S','D']
    for i in range(24):
        encabezados.append("hora "+str(i))
        if(horaactual==i):
            cuerpo[encabezados[i]]=1
        else:
            cuerpo[encabezados[i]]=0
    for i in range(7):
        encabezados.append(dias[i])
        if(diaactual==i):
            cuerpo[dias[i]]=1
        else:
            cuerpo[dias[i]]=0
    cuerpo['traficoactual']=int(traficoactual)
    cuerpo["trafico"]=[3, 10, 20]
    cuerpo['calle']=calle
    cuerpo['fecha']=datetime.datetime.now()+datetime.timedelta(hours=6)
    trafico.insert_one(cuerpo)
    cuerpo.pop('_id')
    return cuerpo
