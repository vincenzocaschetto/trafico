import json
import difflib
import datetime
import requests

import pymongo
from pprint import pprint
client = pymongo.MongoClient("mongodb+srv://tfm:tfm123@cluster0-9biaw.azure.mongodb.net/test?retryWrites=true&w=majority")
db = client.TFM
import datetime
import random
trafico=db.trafico

def myconverter(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()

def lambda_handler(event, context):
    # TODO implement
    calle=event['calle']
    traficoactual=event['traficoactual']
    encabezados=[]
    cuerpo={}
    horaactual=datetime.datetime.now().hour
    diaactual=datetime.datetime.now().weekday()
    dias=['L','M','X','J','V','S','D']
    for i in range(24):
        encabezados.append("hora "+str(i))
        if(horaactual==i):
            cuerpo[encabezados[i]]=1
        else:
            cuerpo[encabezados[i]]=0
    for i in range(7):
        encabezados.append(dias[i])
        if(diaactual==i):
            cuerpo[dias[i]]=1
        else:
            cuerpo[dias[i]]=0
    cuerpo['traficoactual']=int(traficoactual)
    cuerpo["trafico"]=[3, 10, 20]
    cuerpo['calle']=calle
    cuerpo['fecha']=datetime.datetime.now()
    trafico.insert_one(cuerpo)
    cuerpo.pop('_id')
    cuerpo['fecha']=cuerpo['fecha'].__str__()

    
    return cuerpo


